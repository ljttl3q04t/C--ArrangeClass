'use strict'

const puppeteer = require('puppeteer');

(async () => {
    console.log('Open browser.');
    const browser = await puppeteer.launch({
        headless: false
    });

    const page = await browser.newPage();
    const navigationPromise = page.waitForNavigation()

    await page.goto('http://fap.fpt.edu.vn');
    await page.select('#ctl00_mainContent_ddlCampus', '3');
    await page.click('#ctl00_mainContent_btnLoginToGoogle');

    await navigationPromise;
    await page.waitForSelector('input[type="email"]');
    await page.type('input[type="email"]', '<your-email>');
    await page.click('#identifierNext')

    await page.waitForSelector('input[type="password"]', {
        visible: true
    });
    await page.type('input[type="password"]', '<your-password>');
    await page.waitForSelector('#passwordNext', {
        visible: true
    })
    await page.click('#passwordNext')

    await navigationPromise;
    let selector = '#ctl00_mainContent_divMain > div:nth-child(2) > div > table > tbody > tr > td > table > tbody > tr:nth-child(1) > td:nth-child(2) > ul > li:nth-child(3) > a';
    await page.waitForSelector(selector);
    await page.click(selector)


    await navigationPromise;
    //select days
    await Promise.race([
        page.waitForNavigation({waitUntil:'networkidle0'}),
        page.select('#ctl00_mainContent_drpSelectWeek', '38')
    ]);
        
    //select data from table
    let dataFromTableSelector = await page.evaluate(() => document.querySelector('#aspnetForm > table > tbody > tr:nth-child(1) > td > div > table > tbody').innerHTML);
    console.log(dataFromTableSelector);


    //console.log('Close browser.')
    //await browser.close();
})();
